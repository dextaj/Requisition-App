/* ============================================================
   Church Teachers College — Security Groups
   Run once in SSMS against ChurchTeachersCollegeDB.

   Creates:
     Administration.Groups       one row per group
     Administration.UserGroups   junction: which users are in which group
   and seeds the four core groups.

   NOTE: UserID below is declared INT to match a typical
   Administration.Users.UserID identity column. If your Users.UserID
   is a different type (e.g. UNIQUEIDENTIFIER), change the UserID
   column type here to match before running, or the foreign key
   will fail.
   ============================================================ */

/* ---- Groups ------------------------------------------------ */
IF OBJECT_ID('Administration.Groups', 'U') IS NULL
BEGIN
    CREATE TABLE Administration.Groups
    (
        GroupID   INT            IDENTITY(1,1) NOT NULL,
        GroupName NVARCHAR(100)  NOT NULL,
        CONSTRAINT PK_Groups       PRIMARY KEY (GroupID),
        CONSTRAINT UQ_Groups_Name  UNIQUE (GroupName)
    );
END;
GO

/* ---- UserGroups (membership) ------------------------------- */
IF OBJECT_ID('Administration.UserGroups', 'U') IS NULL
BEGIN
    CREATE TABLE Administration.UserGroups
    (
        UserID  INT NOT NULL,
        GroupID INT NOT NULL,
        CONSTRAINT PK_UserGroups PRIMARY KEY (UserID, GroupID),
        CONSTRAINT FK_UserGroups_User
            FOREIGN KEY (UserID)
            REFERENCES Administration.Users (UserID)
            ON DELETE CASCADE,
        CONSTRAINT FK_UserGroups_Group
            FOREIGN KEY (GroupID)
            REFERENCES Administration.Groups (GroupID)
            ON DELETE CASCADE
    );
END;
GO

/* ---- Seed the four core groups ----------------------------- */
INSERT INTO Administration.Groups (GroupName)
SELECT v.GroupName
FROM (VALUES ('Administration'), ('HOD'), ('VP'), ('Principal')) AS v(GroupName)
WHERE NOT EXISTS (
    SELECT 1 FROM Administration.Groups g WHERE g.GroupName = v.GroupName
);
GO
